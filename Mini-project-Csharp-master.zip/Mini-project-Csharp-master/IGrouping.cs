﻿//using System;
//using System.Collections;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace PLWPF
//{
//    public interface IGrouping<out TKey, out TElement> : IEnumerable<TElement>, IEnumerable
//    {
//        TKey Key { get; }
//    }
//}
